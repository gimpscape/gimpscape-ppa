# PASOPATI: Simple GUI Tool to Bulk Resize Your Images

## Dependencies
- ImageMagick
- Yad

## Install
For Debian base distro, get it from [Gimpscape Repository](https://gimpscape.github.io/gimpscape-ppa/)

## Usage
Right click your directory that contain jpg/png images, then open with Pasopati. Click OK after filling all input.


## Disclaimer
This is early development extension. We don't guarantee anything about this extension so please use at your own risk. 

## Support US
This tool is developed by [Devlovers ID](https://dev-is.my.id). You can bought us a cup of coffee if you think this tool helps your daily work.
[I'll send now!](https://support.dev-is.my.id)
